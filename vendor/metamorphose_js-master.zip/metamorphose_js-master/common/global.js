;(function(window) {
if (window) {
    window.metamorphose = {};
}
})(typeof window !== 'undefined' && window);
